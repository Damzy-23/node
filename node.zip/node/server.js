const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// In-memory to-do list storage
let todos = [];
let nextId = 1;

// RESTful API endpoints for to-do list

// Get all to-dos
app.get('/api/todos', (req, res) => {
  res.json(todos);
});

// Add a new to-do
app.post('/api/todos', (req, res) => {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: 'Text is required' });
  }
  const newTodo = { id: nextId++, text, completed: false };
  todos.push(newTodo);
  res.status(201).json(newTodo);
});

// Update a to-do
app.put('/api/todos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { text, completed } = req.body;
  const todo = todos.find(t => t.id === id);
  if (!todo) {
    return res.status(404).json({ error: 'To-do not found' });
  }
  if (text !== undefined) todo.text = text;
  if (completed !== undefined) todo.completed = completed;
  res.json(todo);
});

// Delete a to-do
app.delete('/api/todos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = todos.findIndex(t => t.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'To-do not found' });
  }
  todos.splice(index, 1);
  res.status(204).end();
});

// Additional feature: dynamic greeting endpoint
app.get('/api/greeting', (req, res) => {
  const hour = new Date().getHours();
  let greeting = 'Hello';

  if (hour < 12) {
    greeting = 'Good morning';
  } else if (hour < 18) {
    greeting = 'Good afternoon';
  } else {
    greeting = 'Good evening';
  }

  res.json({ greeting });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
